num_players = 5
num_imposter = 1
num_tasks_per_player = 4
map_width = 8
map_height = 8
vote_threshould = 0.8
num_task_progress_step = 20
kill_cooltime = 30
default_game_map = [
    [1, 0, 0, 3, 3, 3, 0, 0],
    [1, 0, 1, 3, 3, 0, 1, 0],
    [2, 0, 1, 1, 0, 1, 1, 0],
    [0, 0, 1, 2, 0, 0, 1, 0],
    [0, 0, 1, 0, 1, 0, 1, 0],
    [1, 0, 1, 0, 1, 2, 0, 0],
    [1, 0, 1, 0, 1, 1, 1, 0],
    [2, 0, 0, 0, 0, 0, 0, 0],
]
