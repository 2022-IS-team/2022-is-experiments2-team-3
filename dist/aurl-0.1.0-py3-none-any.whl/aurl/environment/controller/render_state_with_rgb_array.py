from ..model import GameState
from .. import config
import numpy as np
from typing import Dict


def render_state_with_rgb_array(state: GameState) -> np.ndarray:
    pass
